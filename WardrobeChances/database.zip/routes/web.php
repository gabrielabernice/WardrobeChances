<?php

use App\Http\Controllers\WController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [WController::class, 'home']);

Route::get('/home', [WController::class, 'home']);

Route::get('/product', [WController::class, 'product']);

Route::get('/detailproduct/{code}', [WController::class, 'detailproduct']);

Route::get('/about', [WController::class, 'about']);

// Route::get('/dashboard', function () {
//     return view('dashboard');
// })->middleware(['auth', 'verified'])->name('dashboard');

// require __DIR__.'/auth.php';
