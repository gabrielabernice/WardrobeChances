@extends('layouts.app')

@section('container')
    <h1>{{ $maintitle }}</h1>
    <p>Contact : hello@mylibrary.com</p>
@endsection