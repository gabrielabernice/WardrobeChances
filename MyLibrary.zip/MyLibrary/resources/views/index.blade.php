@extends('layouts.app')

@section('container')
    <h1>{{ $maintitle }}</h1>
    <table class="table table-striped">
        <tr>
            <td>No</td>
            <td>Name</td>
            <td>Country</td>
            <td>Description</td>
            <td>Contact</td>
            <td>Photo</td>
        </tr>

        @foreach ($writers as $writer)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td><a href="index/{{$writer['id']}}">{{ $writer['name'] }}</a></td>
                <td>{{ $writer['country'] }}</td>
                <td>
                    @if ($loop->first)
                        Urutan Teratas
                    @elseif ($loop->last)
                        Urutan Terbawah
                    @elseif($loop->odd)
                        Urutan Ganjil
                    @elseif($loop->even)
                        Urutan Genap
                    @endif
                </td>
                <td>
                    {{ $writer['contact'] }}
                </td>
                <td>
                    <img src="pictures/{{ $writer['photo'] }}" style="width: 100px; height: 100px">
                </td>
            </tr>
        @endforeach
    </table>
@endsection