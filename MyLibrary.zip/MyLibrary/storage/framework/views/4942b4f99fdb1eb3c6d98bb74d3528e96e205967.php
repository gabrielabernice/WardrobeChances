

<?php $__env->startSection('container'); ?>
    <h1><?php echo e($maintitle); ?></h1>
    <p>Contact : hello@mylibrary.com</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Project\MyLibrary\resources\views/about.blade.php ENDPATH**/ ?>