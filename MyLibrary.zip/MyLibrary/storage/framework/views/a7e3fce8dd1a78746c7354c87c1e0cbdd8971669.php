

<?php $__env->startSection('container'); ?>
    <h1><?php echo e($maintitle); ?></h1>
    <div class="mt-4 p-5 rounded">
        <h1><?php echo e($writers['name']); ?></h1>
        <p>Country : <?php echo e($writers['country']); ?></p>
        <p>Contact : <?php echo e($writers['contact']); ?></p>
        <p>Photo :  <img src=<?php echo e(asset("pictures/{$writers['photo']}")); ?> style="width: 100px; height: 100px"></p>

        <h1>Books</h1>
        <table class="table table-striped">
            <tr>
                <td>No</td>
                <td>Title</td>
                <td>Synopsis</td>
                <td>Cover Photo</td>
            </tr>
    
            <?php $__currentLoopData = $writers->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($book->title); ?></td>
                    <td><?php echo e($book->synopsis); ?></td>
                    <td>
                        <img src=<?php echo e(asset("pictures/{$book['coverphoto']}")); ?> style="width: 100px; height: 100px">
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Project\MyLibrary\resources\views/showwriter.blade.php ENDPATH**/ ?>