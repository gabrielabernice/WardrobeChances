

<?php $__env->startSection('container'); ?>
    <h1><?php echo e($maintitle); ?></h1>
    <table class="table table-striped">
        <tr>
            <td>No</td>
            <td>Name</td>
            <td>Country</td>
            <td>Description</td>
            <td>Contact</td>
            <td>Photo</td>
        </tr>

        <?php $__currentLoopData = $writers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $writer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><a href="index/<?php echo e($writer['id']); ?>"><?php echo e($writer['name']); ?></a></td>
                <td><?php echo e($writer['country']); ?></td>
                <td>
                    <?php if($loop->first): ?>
                        Urutan Teratas
                    <?php elseif($loop->last): ?>
                        Urutan Terbawah
                    <?php elseif($loop->odd): ?>
                        Urutan Ganjil
                    <?php elseif($loop->even): ?>
                        Urutan Genap
                    <?php endif; ?>
                </td>
                <td>
                    <?php echo e($writer['contact']); ?>

                </td>
                <td>
                    <img src="pictures/<?php echo e($writer['photo']); ?>" style="width: 100px; height: 100px">
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Project\MyLibrary\resources\views/index.blade.php ENDPATH**/ ?>