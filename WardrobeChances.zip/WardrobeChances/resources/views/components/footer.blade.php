<div class="text-center py-3 " style="background-color: #c5cfea">

    <h5 class="" style="color: #ffffff"><b>Find Us</b></h5>
    <div class="container text-center " style="width: 200px">
        <div class="row">
            <div class="col">
                <a href="https://instagram.com/wardrobechances?igshid=YmMyMTA2M2Y="><img src={{ asset('pictures/1.svg') }}
                        class="card-img-top" alt="..."></a>
            </div>
            <div class="col">
                <a href="https://www.tiktok.com/@wardrobechances?_t=8WxjTjl4Aao&_r=1"><img src={{ asset('pictures/2.svg') }}
                        class="card-img-top" alt="..."></a>
            </div>
            <div class="col">
                <a href="https://wa.me/6285173380018"> <img src={{ asset('pictures/3.svg') }} class="card-img-top"
                        alt="..."></a>
            </div>
        </div>
    </div>
    <p class=" mt-3 mx-5 px-5" style="color: #ffffff">Wardrobe Chances' business concept offers fashion and
        quality with the best deal.
        Established on 2021, Wardrobe Chances has been providing the best re-worked thrift in town. All
        contents and informations in this website are protected by the copyright of Wardrobe Chances.</p>


</div>
<div class="text-center p-2 pt-4" style="color: #ffffff; background-color: #b6bfd9">
    <p style="font-size: 12px"> Copyright ©WardrobeChances All Rights Reserved.</p>
</div>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js"
    integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous">
</script>