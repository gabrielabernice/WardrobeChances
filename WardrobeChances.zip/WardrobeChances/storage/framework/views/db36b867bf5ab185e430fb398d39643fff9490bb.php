

<?php $__env->startSection('container'); ?>
<div class="d-flex mx-auto">
    <h1 class="text-center pt-2"><?php echo e($maintitle); ?></h1>

</div>
    <div class="container text-center ">
        <div class="row mb-5">
            <?php $__currentLoopData = $clothes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clothe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-auto col-md-4 mx-auto ">
                    <div class="card my-4 mx-auto" style="width: 15rem; background-color:#dce6ff">
                        <img src="<?php echo e(asset("pictures/{$clothe['photo']}")); ?>" class="card-img-top" style=" height: 230px" alt="Product picture">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($clothe['name']); ?></h5>
                            <p class="card-text">Size : <?php echo e($clothe['size']); ?></p>
                            <div class="d-flex">
                                <a href="/detailproduct/<?php echo e($clothe['code']); ?>" style="background-color:#516ab0; color: #ffffff"  class="btn  align-items-center justify-content-center mx-auto">Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Project\WardrobeChances\resources\views/product.blade.php ENDPATH**/ ?>